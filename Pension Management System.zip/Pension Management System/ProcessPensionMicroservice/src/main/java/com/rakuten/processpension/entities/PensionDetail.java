package com.rakuten.processpension.entities;

public class PensionDetail {
	private Double pension_amount;
	private int bank_service_charge;
	public Double getPension_amount() {
		return pension_amount;
	}
	public void setPension_amount(Double pension_amount) {
		this.pension_amount = pension_amount;
	}
	public int getBank_service_charge() {
		return bank_service_charge;
	}
	public void setBank_service_charge(int bank_service_charge) {
		this.bank_service_charge = bank_service_charge;
	}
	
	
}
