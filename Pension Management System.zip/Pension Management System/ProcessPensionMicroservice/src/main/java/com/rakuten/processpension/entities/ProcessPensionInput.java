package com.rakuten.processpension.entities;

import java.math.BigInteger;

public class ProcessPensionInput {
	private BigInteger aadhar_number;

	public BigInteger getAadhar_number() {
		return aadhar_number;
	}

	public void setAadhar_number(BigInteger aadhar_number) {
		this.aadhar_number = aadhar_number;
	}
	
}
