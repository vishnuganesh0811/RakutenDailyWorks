package com.rakuten.processpension.entities;

public enum PensionClassification {
	SELF, FAMILY
}
