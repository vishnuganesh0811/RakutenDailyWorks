package com.rakuten.processpension.entities;

public enum BankType {
	PRIVATE, PUBLIC
}
