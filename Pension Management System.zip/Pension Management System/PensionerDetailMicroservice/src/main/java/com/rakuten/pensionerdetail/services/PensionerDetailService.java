package com.rakuten.pensionerdetail.services;

public class PensionerDetailService {

}
