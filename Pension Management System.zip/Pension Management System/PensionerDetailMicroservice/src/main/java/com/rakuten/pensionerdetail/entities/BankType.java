package com.rakuten.pensionerdetail.entities;

public enum BankType {
	PRIVATE, PUBLIC
}
