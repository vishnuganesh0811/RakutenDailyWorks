package com.rakuten.pensionerdetail.entities;

public enum PensionClassification {
	SELF, FAMILY
}
