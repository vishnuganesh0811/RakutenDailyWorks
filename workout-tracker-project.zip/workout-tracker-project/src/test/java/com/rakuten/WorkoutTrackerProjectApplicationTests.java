package com.rakuten;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkoutTrackerProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
